import { Fragola } from "@fragola-ai/agentic";

export const fragola = new Fragola({});