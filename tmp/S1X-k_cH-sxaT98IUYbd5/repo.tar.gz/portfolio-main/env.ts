declare namespace NodeJS {
    interface ProcessEnv {
        AZURE_RESOURCE_NAME: string;
        AZURE_API_KEY: string;
    }
}