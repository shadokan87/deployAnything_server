// tailwind.config.js
module.exports = {
  // ...existing config...
  plugins: [
    require('@tailwindcss/typography'),
    // ...other plugins...
  ],
}