import Image from "next/image";
import Prompt from "@fragola-ai/prompt";

export default function Home() {
  return (
    <div>
    </div>
  );
}
