export default function GitHubCallback() {
  return (
    <div>
      <h1>GitHub Callback</h1>
      <p>Processing GitHub authentication...</p>
    </div>
  );
}
